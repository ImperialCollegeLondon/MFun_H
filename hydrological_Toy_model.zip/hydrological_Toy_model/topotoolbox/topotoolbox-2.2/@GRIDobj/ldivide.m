function OUT = ldivide(varargin)

funname = 'ldivide';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});